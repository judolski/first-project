-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2017 at 09:59 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `baptism`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'kizito', 'judolski');

-- --------------------------------------------------------

--
-- Table structure for table `bap_records`
--

CREATE TABLE IF NOT EXISTS `bap_records` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) NOT NULL,
  `bname` varchar(20) NOT NULL,
  `oname` varchar(20) NOT NULL,
  `faname` varchar(40) NOT NULL,
  `moname` varchar(40) NOT NULL,
  `gfmname` varchar(40) NOT NULL,
  `priname` varchar(40) NOT NULL,
  `dob` varchar(11) NOT NULL,
  `dobp` varchar(11) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `image` varchar(50) NOT NULL,
  `date_of_reg` varchar(11) NOT NULL,
  `time_of_reg` varchar(8) NOT NULL,
  `user` varchar(15) NOT NULL,
  `updated_date` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `bap_records`
--

INSERT INTO `bap_records` (`id`, `sname`, `bname`, `oname`, `faname`, `moname`, `gfmname`, `priname`, `dob`, `dobp`, `gender`, `image`, `date_of_reg`, `time_of_reg`, `user`, `updated_date`) VALUES
(1, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:40:43', 'judolski', ''),
(2, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:40:52', 'judolski', ''),
(3, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:40:57', 'judolski', ''),
(4, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:41:02', 'judolski', ''),
(5, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:41:08', 'judolski', ''),
(6, 'white', 'christopher', 'okechukwu', 'white michael', 'white doraty', 'snow joseph', 'Rev. Fr. kilox john', '2017-03-08', '2017-05-10', 'Male', 'uploads/FB_IMG_1473787565096.jpg', '28-11-2017', '01:41:14', 'judolski', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(2) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `uname` varchar(15) NOT NULL,
  `pword` varchar(15) NOT NULL,
  `date` varchar(11) NOT NULL,
  `time` varchar(7) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `sname`, `fname`, `uname`, `pword`, `date`, `time`) VALUES
(2, 'Owo', 'chidi', 'judolski', '111111', '30-10-2017', '07:02:2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
